MOODWAVE PWA package

Upload these five files to the ROOT of your GitHub repository: index.html, manifest.json, sw.js, icon-192.png, icon-512.png. Then enable GitHub Pages from Settings > Pages, branch main, folder /(root). Open the published URL in Chrome and choose Install app / Add to Home screen.
